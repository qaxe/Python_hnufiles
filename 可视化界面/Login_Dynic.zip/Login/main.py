import sys

from FunctionToUi import *


class Designer_Login(Ui_MainWindow, QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setupUi(self)
        FunctionToUi.ShawFunction(self)
        self.Btn_Login.clicked.connect(self.LoginFunction)

    def Ui_Function(self):
        FunctionToUi.FunctionMoveWindow(self)

    def LoginFunction(self):
        User = str(self.Login_User_Input.text())
        Password = str(self.Login_Pa_Input.text())
        print('User:' + User + '\n' + 'Password:' + Password)


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    Ui = Designer_Login()
    Ui.show()
    sys.exit(app.exec_())
