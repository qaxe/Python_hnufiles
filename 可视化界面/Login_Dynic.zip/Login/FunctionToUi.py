from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import QRect, QEasingCurve

from Ui_From import Ui_MainWindow


class FunctionToUi(Ui_MainWindow):
    def ShawFunction(self):
        # 滑动模块阴影
        self.Cer_Widget.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect
            (blurRadius=40, xOffset=1, yOffset=1, color=QtGui.QColor(0, 0, 0)))
        # 标题光影
        self.Title_Login.setGraphicsEffect(
                            QtWidgets.QGraphicsDropShadowEffect
                                    (blurRadius=4, xOffset=1, yOffset=1, color=QtGui.QColor(0, 0, 0)))
        # 背景登录标题光影
        self.Login_title.setGraphicsEffect(
                    QtWidgets.QGraphicsDropShadowEffect
                            (blurRadius=0, xOffset=1, yOffset=1, color=QtGui.QColor(0, 0, 0)))
        # 背景注册标题光影
        self.Sign_title.setGraphicsEffect(
            QtWidgets.QGraphicsDropShadowEffect
            (blurRadius=0, xOffset=1, yOffset=1, color=QtGui.QColor(0, 0, 0)))


        # 实例化动画  对象登录滑块
        self.TarGet = self.Cer_Widget
        self._animation = QtCore.QPropertyAnimation(self.TarGet)
        self._animation.setTargetObject(self.TarGet)
        self._animation.setPropertyName(b"geometry")
        self._animation.setDuration(1200)
        self._animation.setEasingCurve(QEasingCurve.OutElastic)

    def FunctionMoveWindow(self):
        BtnObject = self.sender()
        BtnName = BtnObject.objectName()
        # print(BtnName)
        if BtnName == 'Btn_Sign':
            self.Title_Login.setText('SignUp')

            # 移动动画
            self._animation.setStartValue(QRect(250, 60, 401, 651))
            self._animation.setEndValue((QRect(550, 60, 401, 651)))
            self._animation.start()

        if BtnName == 'Btn_Login_2':
            self.Title_Login.setText('Login')

            # 移动动画
            self._animation.setStartValue((QRect(550, 60, 401, 651)))
            self._animation.setEndValue(QRect(250, 60, 401, 651))
            self._animation.start()