Author
    DesignerBy QQ 1019383856
    BiliBili CiLang
    Gitee CiLang

Explain
    QQ代码仓库 954736632
    仓库群内可以提问闲聊 提问最好把图片放上来
    也欢迎各位大佬, 萌新进群
    代码开源 不支持用来倒卖卖课

Demo 
    非官方 https://github.com/pyqt/examples/tree/_/src
    老版的教学 https://zetcode.com/pyqt/

Warning
    不要拿我开源的代码拿去卖钱和卖课
    也不要像 这个人去盗别人视频 
    https://space.bilibili.com/485478576?share_medium=android&share_source=copy_link&bbid=XY7F16F7600E1FF9EF88208AFB518D9C27768&ts=1650368246845 
    ![image](image_01.jpg)
    虽然删了但是污点是删不掉的
